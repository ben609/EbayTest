package pages;


import java.util.Properties;

import utilty.Reporting;
import utilty.Utility;

public class Homepage extends Utility {
	
	String Searchbox="com.amazon.mShop.android.shopping:id/rs_search_src_text";
	String productname="com.amazon.mShop.android.shopping:id/item_title";
	
	/*Method to Search for a Product By Entering Text in Search box
	 * Created By : Benarji Enamandala
	 */
public void SearcBox(Reporting report) {
	try {
		
		Properties pro=new Properties();
		pro=propFile(System.getProperty("user.dir")+"\\src\\main\\java\\resources\\config.properties");	
		

	clickElement("id", Searchbox,report);
	Thread.sleep(5000);
	Sendkeys("id", Searchbox,pro.getProperty("Product"),report);
	Enter(report);
	Thread.sleep(15000);
	
// Repeating Above Code again due to App Redirection to Amazon Home page again  
	clickElement("id", Searchbox,report);
	Thread.sleep(5000);
	System.out.println();
	Sendkeys("id", Searchbox,pro.getProperty("Product"),report);
	Enter(report);
	
	report.Reportpass("Product Search Completed");
	}
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		report.Reportfail(e.getMessage());
	}
}

/*Method to Select random Product From Search  List
 * Created By : Benarji Enamandala
 */
	
public void SelectProduct(Reporting report) {
try {
	
	randSelection("id",productname ,report);
	report.Reportpass("Selected Random Product Success");
	
}catch (Exception e) {
	e.printStackTrace();
	report.Reportfail(e.getMessage());
	// TODO: handle exception
	
}
	
}
	
}
