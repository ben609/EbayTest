package pages;

import utilty.Reporting;
import utilty.Utility;

public class CartPage extends Utility{
	String productname= "//*[@resource-id='activeCartViewForm']//*[@class='android.widget.Image']";
	String checkout="a-autoid-0-announce";
	
	
	/*Method to compare Products Added in Cartpage equals Product Selected
	 * Created By : Benarji Enamandala
	 */
	public void CompareProduct(String Product,Reporting report) {
		String Cartproductname=null;
		try {
		
		Cartproductname=getText("xpath", productname, report);
			verifyText(Cartproductname,Product , report);
			report.Reportpass("Product matched");
		}catch (Exception e) {
			report.Reportfail(e.getMessage());
			// TODO: handle exception
		}
	}
	
	/*Method to Click on Checkout Button
	 * Created By : Benarji Enamandala
	 */
	public void Checkout(Reporting report) {
		try {
		clickElement("id", checkout, report);
		report.Reportpass("Navigated to checkout");
		}catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			report.Reportfail(e.getMessage());
		}
	}
	
}
