package pages;

import utilty.Reporting;
import utilty.Utility;

public class SigninPage extends Utility{

	String Skipsignin = "com.amazon.mShop.android.shopping:id/skip_sign_in_button";
	



public void Skipsignin(Reporting report) throws InterruptedException {
	try {
		
	
	Thread.sleep(15000);
	clickElement("id",Skipsignin,report);
	report.Reportpass("skipped sign in");
	}catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	report.Reportfail(e.getMessage());
	}
	
}


}