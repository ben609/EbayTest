package mainActivity;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.Homepage;
import pages.ProductDesc;
import pages.SigninPage;
import utilty.Reporting;
import utilty.Utility;

public class MainActivity extends Utility {
	Reporting extentreport;
	
	/*Constructor calling Utility Class Constructor 
	 * Created By : Benarji Enamandala
	 */
public MainActivity() {
	// TODO Auto-generated constructor stub
	super();
}

/* Before Test to initialize drivers and Reports
 * Created By : Benarji Enamandala
 */
	@BeforeTest
	public void Before() {
		
		MainActivity m=new MainActivity();  // MainActivity Object created to call  Constructor
		extentreport=new Reporting();  //creating object for Reporting
		extentreport.extentReportInit();
		extentreport.logger=extentreport.report.createTest("AppTest");
		driverIni(extentreport); //passing report object to Utility driver initiating
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
	}
	
	/*Main Test Method 
	 * Created By : Benarji Enamandala
	 */
	@Test
	public void Test1() throws InterruptedException {
		try {
		new SigninPage().Skipsignin(extentreport);
		Thread.sleep(5000);
		new Homepage().SearcBox(extentreport);
		new Homepage().SelectProduct(extentreport);
		String name=new ProductDesc().getproductname(extentreport);
		new ProductDesc().AddToCart(extentreport); 
		new ProductDesc().Opencart(extentreport);
		new CartPage().CompareProduct(name,extentreport);
		new CartPage().Checkout(extentreport);
	
		
	}catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		extentreport.Reportfail(e.getMessage());
	}
			
	}
	/*After Method to get all failed reports
	 * Created By : Benarji Enamandala
	 */
	
	@AfterMethod
	public void getResult(ITestResult result) throws IOException
    {
        if(result.getStatus() == ITestResult.FAILURE)
        {
            
            extentreport.Reportfail(result.getThrowable().getMessage());
       }
    }
	/*AfterTest Method to Quit Driver
	 * Created By : Benarji Enamandala
	 */
	@AfterTest
	public void After() {
		extentreport.report.flush();
		driver.quit();
		
	}

}
