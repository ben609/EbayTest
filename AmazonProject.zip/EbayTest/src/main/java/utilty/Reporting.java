package utilty;

import java.io.File;
import java.io.FileInputStream;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;

import com.aventstack.extentreports.reporter.ExtentHtmlReporter;


public class Reporting extends Utility{
	
	public ExtentHtmlReporter extentHtmlReport;
	public ExtentReports report;
	public ExtentTest logger;
	

	

/*
 * Method to Initialize Extent Reports
 * Created by : Benarji Enamandala
 * 
 */
public void extentReportInit() {
	extentHtmlReport=new ExtentHtmlReporter(new File(System.getProperty("user.dir")+"/Reports/Result.html")); 
	report=new ExtentReports();
	report.attachReporter(extentHtmlReport);
	
}

/*
 * Method to report passed Reports Statements using Extent reports
 * Created by : Benarji Enamandala
 * 
 */
public void Reportpass(String d) {
	String ss=new Reporting().captureScreen();
	try {
		this.logger.pass(d,MediaEntityBuilder.createScreenCaptureFromPath(ss).build());
	
	}catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
}
/*
 * Method to report Failed Executions Using Extent Reports
 * Created by : Benarji Enamandala
 * 
 */
public void Reportfail(String d) {
	String ss=new Reporting().captureScreen();
	try {
		this.logger.fail(d,MediaEntityBuilder.createScreenCaptureFromPath(ss).build());
	
	}catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	
}
/*
 * Method to Capture Screenshots
 * Created by : Benarji Enamandala
 * 
 */

public String captureScreen() {
	
	String  Dest=null ;
	File srcfile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	FileInputStream fis=null;
	try {
		fis=new FileInputStream(srcfile);
		byte[] b=new byte[(int)srcfile.length()];
		fis.read(b);
		// capturing screenshot as output type file from getScreenshotAs method by up casting the AndroidDriver reference to TakeScreenshot Interface
		Dest=System.getProperty("user.dir")+"/Reports/Screenshots/"+System.currentTimeMillis()+".png";
		// Coping screenshot file into Screenshots folder with Filename from  argument along with current time appended to file name
	File  Destfile=new File(Dest);
	FileUtils.copyFile(srcfile,Destfile);
				 
		
	}catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	
	
	return Dest;
	
}
}
